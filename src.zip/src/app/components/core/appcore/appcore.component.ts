import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appcore',
  templateUrl: './appcore.component.html',
  styleUrls: ['./appcore.component.css']
})
export class AppcoreComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
