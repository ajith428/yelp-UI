import {WeatherData} from './weatherdata.model'

export class ForecastDetails extends WeatherData{
    public date? : string
  }