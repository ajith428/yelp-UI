import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

const yelpBasePath: string = 'https://corsanywhere.herokuapp.com/https://api.yelp.com/v3/businesses/';
@Injectable({
  providedIn: 'root'
})
export class YelpService {
  constructor(private http: HttpClient) { }
  
  getBusinessReviews(id: string, context: any) {
    this.http.get(yelpBasePath + id + "/reviews", { headers: { 'Authorization': 'Bearer 9ejLORKsQnr8xFJrWV8rQmRx0HQV_G443_wXMtTxy9NAYsBsgvxe6zMUwIQFfOdhNafiYX23Nyelv3PhRaNWnht2ETt8rzlCXoEHL9s38J8MoLMfJ2YcTAaHqAxuYXYx' } }).subscribe(
      res => {
        context.setBusinessReviews(res)
      }
    )
  }

  getYelpReviews(business: string, location: string, context: any) {
    this.http.get(yelpBasePath + "search?term=" + business + "&location=" + location, { headers: { 'Authorization': 'Bearer 9ejLORKsQnr8xFJrWV8rQmRx0HQV_G443_wXMtTxy9NAYsBsgvxe6zMUwIQFfOdhNafiYX23Nyelv3PhRaNWnht2ETt8rzlCXoEHL9s38J8MoLMfJ2YcTAaHqAxuYXYx' } }).subscribe(
      res => {
        context.setYelpReviews(res)
      }
    )
  }

}
