
export class ReviewData {
    public name? : string
    public reviewText? : String;
    public rating?: number;
    public date: any;
    public imageurl?: string;

  }